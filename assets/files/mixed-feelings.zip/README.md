# Orbital Game Jam 4 - Aqua

Discover the world living in the leaves lying on the floor of a mysterious forest. Use your planning
 skills to gather seeds and change their color to adapt to the emotions of your customers. Be kind, 
 listen well. It feels good to be empathic.

And remember: everyone is weird and that's fine!

This game was created in 24 hours during the 4th edition of the Orbital Game Jam in Lausanne, Switzerland.

## Run the game

To run the game, you can run the following commands:

```
python -m venv .
source ./bin/activate
pip3 -r requirements.txt
make run
```

Enjoy!

## Compile the game

It is possible to package this game in binaries.

We provide a Github worklow file in `.github/workflows/build.yaml` which will build the game for Linux, MacOS
and Windows, and expose them as artifacts.

If you prefer building locally, you can run `make linux` or `make windows` depending on the platform you're running on.